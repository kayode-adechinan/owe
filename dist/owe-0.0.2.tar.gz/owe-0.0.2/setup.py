import setuptools

setuptools.setup(
    name="owe",
    version="0.0.2",
    author="Kayode Adechinan",
    author_email="kayode.adechinan@gmail.com",
    description="simple python package hosted on Github",
    packages=setuptools.find_packages(),
    license='MIT',
    zip_safe=False
)
